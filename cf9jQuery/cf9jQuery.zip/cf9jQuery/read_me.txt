To set up a site to use this code, you will need to drop the contents of the 'www' folder into the web root of an application.

You will need to create a ColdFusion datasource (Apache Derby Embedded), names 'max09', that points to the data/max09 directory.