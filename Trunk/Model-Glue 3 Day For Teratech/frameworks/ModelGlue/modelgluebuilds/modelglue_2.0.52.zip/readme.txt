Model-Glue
1.1.00 (April 10, 2006)
Joe Rinehart (joe.rinehart@gmail.com)

Well, now you've gone and done it.  

You're probably thinking "Ok, I've downloaded it, what next?"

As the good book says:  "Don't Panic"

There are detailed installation instructions in the ModelGlue/Documentation/Quickstart/index.html file, but this should get you started:

1. Copy the ModelGlue folder to /ModelGlue.  The framework is now installed.  If you a mapping instead, you're probably advanced enough to figure out what they're all about.

2. Copy the modelgluesamples folder to /modelgluesamples.  The samples are now installed.

3. Run some samples - try http://[host]/modelgluesamples/legacysamples/nameuppercaser or http://[host]/modelgluesamples/legacysamples/contactmanager .  If they don't run, drop me a line at joe.rinehart@gmail.com .

4. Read the quickstart at ModelGlue/Documentation/Quickstart/index.html

5. Look at the example applications' controller/Controller.cfc and config/ModelGlue.xml config files for further examples.

Changelog:

