This set of samples requires the following:


1.  MySQL 5.x to be installed
2.  A datasource named "mgsamples_mysql" pointing to a database (name it anything, but "mgsamples_mysql" is good)
3.  Running the following script against the database:

CREATE TABLE  role (
  roleId int(11) NOT NULL auto_increment,
  name varchar(45) NOT NULL default '',
  allowsKeys tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (roleId)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE  user (
  userId int(11) NOT NULL auto_increment,
  username varchar(45) NOT NULL default '',
  password varchar(45) NOT NULL default '',
  PRIMARY KEY  (userId)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE  userrole (
  userroleid int(11) NOT NULL auto_increment,
  userid int(11) NOT NULL,
  roleId int(11) NOT NULL,
  `key` int(10) zerofill NOT NULL DEFAULT '00000000',
  PRIMARY KEY  (userroleid),
  KEY FK_userrole_user_userid (userid),
  KEY FK_userrole_role_roleId (roleId),
  CONSTRAINT FK_userrole_role_roleId FOREIGN KEY (roleId) REFERENCES role (roleId),
  CONSTRAINT FK_userrole_user_userid FOREIGN KEY (userid) REFERENCES user (userId)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO role (
	name
) VALUES (
	'Administrator'
);

INSERT INTO role (
	name,
	allowsKeys
) VALUES (
	'ListEditor',
	1
);

INSERT INTO user (
	username,
	password
) VALUES (
	'Administrator',
	'Administrator'
);

INSERT INTO userrole (
	userid,
	roleId
) VALUES (
	1,
	1
);

CREATE TABLE  list (
  listid int(11) NOT NULL auto_increment,
  name varchar(45) NOT NULL default '',
  userid int(11) NOT NULL default '0',
  PRIMARY KEY  (listid)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE  task (
  taskid int(11) NOT NULL auto_increment,
  listid int(11) NOT NULL default '0',
  name varchar(45) NOT NULL default '',
  complete tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (taskid)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO list (
	name,
	userid
) VALUES (
	'Administrator List',
	1
);

INSERT INTO userrole (
	userId,
	roleId,
	`key`
) VALUES (
	1,
	2,
	1
);

CREATE TABLE  film (
  filmId int(11) NOT NULL auto_increment,
  title varchar(100) NOT NULL default '',
  PRIMARY KEY  (filmId)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE  filmgenre (
  filmgenreid int(11) NOT NULL auto_increment,
  filmid int(11) NOT NULL default '0',
  genreid int(11) NOT NULL default '0',
  PRIMARY KEY  (filmgenreid)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE  genre (
  genreId int(11) NOT NULL auto_increment,
  name varchar(45) NOT NULL default '',
  PRIMARY KEY  (genreId)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




