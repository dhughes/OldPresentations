CREATE TABLE [user] (
	[userId] [int] IDENTITY (1, 1) NOT NULL ,
	[username] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[password] [nvarchar] (45) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	CONSTRAINT [PK_user] PRIMARY KEY  CLUSTERED 
	(
		[userId]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO

CREATE TABLE [role] (
	[roleId] [int] IDENTITY (1, 1) NOT NULL ,
	[name] [nvarchar] (45) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[allowsKeys] [bit] NOT NULL CONSTRAINT [DF_role_allowsKeys] DEFAULT (0),
	CONSTRAINT [PK_role] PRIMARY KEY  CLUSTERED 
	(
		[roleId]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO

CREATE TABLE [userrole] (
	[userroleid] [int] IDENTITY (1, 1) NOT NULL ,
	[userid] [int] NOT NULL ,
	[roleid] [int] NOT NULL ,
	[key] [int] NULL CONSTRAINT [DF_userrole_key] DEFAULT (0),
	CONSTRAINT [PK_userrole] PRIMARY KEY  CLUSTERED 
	(
		[userroleid]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO


INSERT INTO role (
	name
) VALUES (
	'Administrator'
)

GO

INSERT INTO [user] (
	username,
	password
) VALUES (
	'Administrator',
	'Administrator'
)

GO

INSERT INTO userrole (
	userid,
	roleId
) VALUES (
	1,
	1
)

GO
