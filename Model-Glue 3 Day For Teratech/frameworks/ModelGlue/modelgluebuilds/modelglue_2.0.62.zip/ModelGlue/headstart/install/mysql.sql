DROP TABLE IF EXISTS role;

CREATE TABLE  role (
  roleId int(11) NOT NULL auto_increment,
  name varchar(45) NOT NULL default '',
  allowsKeys tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (roleId)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS user;
CREATE TABLE  user (
  userId int(11) NOT NULL auto_increment,
  username varchar(45) NOT NULL default '',
  password varchar(45) NOT NULL default '',
  PRIMARY KEY  (userId)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS userrole;
CREATE TABLE  userrole (
  userroleid int(11) NOT NULL auto_increment,
  userid int(11) NOT NULL,
  roleId int(11) NOT NULL,
  `key` int(10) zerofill NOT NULL DEFAULT '00000000',
  PRIMARY KEY  (userroleid),
  KEY FK_userrole_user_userid (userid),
  KEY FK_userrole_role_roleId (roleId),
  CONSTRAINT FK_userrole_role_roleId FOREIGN KEY (roleId) REFERENCES role (roleId),
  CONSTRAINT FK_userrole_user_userid FOREIGN KEY (userid) REFERENCES user (userId)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO role (
	name
) VALUES (
	'Administrator'
);

INSERT INTO user (
	username,
	password
) VALUES (
	'Administrator',
	'Administrator'
);

INSERT INTO userrole (
	userid,
	roleId
) VALUES (
	1,
	1
);



