Model-Glue
2.something (Sometime, 2006)
Joe Rinehart (joe.rinehart@gmail.com)

Well, now you've gone and done it.  

You're probably thinking "Ok, I've downloaded it, what next?"

As the good book says:  "Don't Panic"

There are detailed installation instructions in the ModelGlue/Documentation/Quickstart/index.html file, but this should get you started:

1. Download and install ColdSpring from http://www.coldspringframework.org

2. Use Subversion to get and install the latest version of Reactor.  It's not available as a .zip yet, and you're testing an alpha version of this whole schebang.  The SVN url is svn://www.alagad.com/reactor/trunk/reactor

3. Copy the ModelGlue folder to whatever ColdFusion sees as "/ModelGlue".  The framework is now installed.  If you need a mapping instead, you're probably advanced enough to figure out what they're all about.

4. Copy the modelgluesamples folder to /modelgluesamples.  The samples are now installed.

5. Run some samples - try http://[host]/modelgluesamples/legacysamples/nameuppercaser or http://[host]/modelgluesamples/legacysamples/contactmanager .  If they don't run, drop me a line at joe.rinehart@gmail.com .


Changelog:

